package infothunder.reactive.profile

import akka.actor.Actor.Receive
import akka.actor.{ActorLogging, Actor}

/**
 * Created by Simon Wang on 2014/11/27.
 */




class ProfileActor extends Actor with ActorLogging{
  override def receive = {
    case _ =>

  }
}
